#### -- Packrat Autoloader (version 0.4.8-54) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
